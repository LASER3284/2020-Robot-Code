import cv2 as cv
import numpy as np
import json
import glob
import os

# Open the camera calibration JSON file.
with open("output_param.json") as json_file:
	data = json.load(json_file)
	mtx = np.array(data["camera_matrix"])
	dist = np.array(data["distortion"])
	
# Open the camera images in current directory with glob.
cap = cv.VideoCapture("video.mp4")
	
# Use OpenCV to undistort an image from the camera. 
x = 0
while(1):
	# Read images with OpenCV.
	#img = cv.imread(fname)
	ret, img = cap.read()
	
	# Scale the camera matrix.
	h, w = img.shape[:2]
	newcameramtx, roi = cv.getOptimalNewCameraMatrix(mtx, dist, (w,h), 1, (w,h))
	
	# Undistort the image using the provided camera matrix values.
	dst = cv.undistort(img, mtx, dist, None, newcameramtx)
	
	if cv.waitKey(1) & 0xFF == ord('q') or ret==False :
		cap.release()
		cv2.destroyAllWindows()
		break
	
	cv.imshow("Undistorted", dst)
	#cv.imwrite(os.path.join("/home/ccowen/Desktop/Camera Calibration/Undistorted Images/", "image" + str(x) + ".jpg", dst)
	x += 1
